import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

import './scss/_custom.scss';

import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { RouterProvider } from 'react-router-dom';
import AppRoutes from './routes/App.routes.tsx';
import { Provider } from 'react-redux';
import { store } from './app/store.ts';

createRoot(document.getElementById('root')!).render(
    <StrictMode>
        <Provider store={store}>
            <RouterProvider router={AppRoutes} />
        </Provider>
    </StrictMode>,
)
