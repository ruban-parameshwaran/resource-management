export default function Footer() {
    return(
        <div className="py-6 px-6 text-center">
            <p className="mb-0 fs-4">Design and Developed by : Ruban Parameshwaran</p>
        </div>
    )
}