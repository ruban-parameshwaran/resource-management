import { AppConst } from '@src/const/AppConst';
import axios from 'axios';

class AuthService {

    baseUrl = AppConst.ApiURL;

    async login(username: string, password: string) {
        const response = await axios.post(`${this.baseUrl}/login`, { username, password });
        return response.data;  
    }

}

export const authService = new AuthService();